<footer class="footer">
  <p>&copy; <?php echo __('Tous droits réservés'); ?></p>
</footer>
<?php wp_footer(); ?>
</body>
</html>