<?php get_header(); ?>

<div class="container">

<?php
if ( have_posts() ) {
  while ( have_posts() ) {
    the_post();
    the_content();
  }
}
?>

</div>

<?php $lien = get_field('banner_register_link'); ?>

<div id="banner">
    <h1 id="banner_baseline"><?php the_field('banner_baseline'); ?></h1>
    <h2 id="banner_brown_title"><?php the_field('banner_brown_title'); ?></h2>
    <h3 id="banner_green_title"><?php the_field('banner_green_title'); ?></h3>
    <a href="<?php echo $lien['url']; ?>" id='banner_register_link' > <?php echo $lien['title']; ?></a>
    <style>
      #banner {
        background-image: url(<?php the_field('banner_background_image'); ?>);
      }
    </style>
</div>

<div id="conference">
    <h1 id="conference_title"><?php the_field('conference_title'); ?></h1>
    <h3 id="line">__________________</h3>
    <h2 id="conference_content"><?php the_field('conference_content'); ?></h2>
    <div id="conference_image">
        <style>
          #conference_image {
            background-image: url(<?php the_field('conference_image'); ?>);
          }
        </style>
    </div>
</div>


<div id="program">

</div>



<?php get_footer(); ?>
